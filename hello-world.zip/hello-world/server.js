console.log("hello from node"); 
var port=3000;
var express = require("express");
var	app=express();

// middleware
	app.use('/node_modules',express.static(_dirname='node_modules'));
	app.use('/controller',express.static(_dirname='app/controller'));
app.get('/',
		function(req,res){
		res.sendfile(_dirname="app/view/index.html")
		}
	);


app.listen(port,function(){
		console.log("port is open");
})