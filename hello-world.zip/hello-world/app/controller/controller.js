var app=angular.module('app',[]);

app.controller('controller',['$scope',function($scope) {
	// body...
	$scope.value="HELLO WORLD";
	$scope.Heading="welcome to MEAN Project"

}]);